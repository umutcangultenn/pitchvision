---
name: Tactical Performance System
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#414844'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#717973'
  outline-variant: '#c1c8c2'
  surface-tint: '#3f6653'
  primary: '#012d1d'
  on-primary: '#ffffff'
  primary-container: '#1b4332'
  on-primary-container: '#86af99'
  inverse-primary: '#a5d0b9'
  secondary: '#00677d'
  on-secondary: '#ffffff'
  secondary-container: '#72ddfd'
  on-secondary-container: '#006075'
  tertiary: '#3f1d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#5f2f00'
  on-tertiary-container: '#fd8704'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c1ecd4'
  primary-fixed-dim: '#a5d0b9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#274e3d'
  secondary-fixed: '#b2ebff'
  secondary-fixed-dim: '#69d4f4'
  on-secondary-fixed: '#001f27'
  on-secondary-fixed-variant: '#004e5f'
  tertiary-fixed: '#ffdcc4'
  tertiary-fixed-dim: '#ffb781'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#703800'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  data-mono:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 24px
  headline-lg-mobile:
    fontFamily: Montserrat
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style

This design system is built for the high-stakes environment of sports coaching, where clarity and speed of insight are paramount. The brand personality is **authoritative yet supportive**, bridging the gap between complex data science and on-field application. 

The visual style is **Modern Corporate with a High-Performance edge**. It utilizes a "Tactical Layering" approach: essential data is brought to the foreground using high-contrast accents, while secondary information recedes into a structured, clean grid. The aesthetic avoids the clutter of traditional "academic" analytics in favor of a sleek, broadcast-inspired interface that feels energetic and ready for action.

Key design principles:
- **Tactical Clarity:** Use visual hierarchy to guide a coach's eye to the most critical "win-loss" metrics first.
- **Athletic Precision:** Every line, margin, and icon should feel intentional and disciplined.
- **Actionable Data:** Data isn't just displayed; it is framed to suggest a decision or a coaching adjustment.

## Colors

The palette is rooted in the natural environment of sport—the "Pitch Green"—complemented by technical accents that denote performance and urgency.

- **Primary (Pitch Green - #1B4332):** Used for primary branding, navigation backgrounds, and success states. It represents the field of play.
- **Secondary (Performance Blue - #219EBC):** Dedicated to data visualization, interactive elements, and tactical movements. It provides a cool, analytical contrast to the green.
- **Tertiary (Alert Orange - #FB8500):** Reserved strictly for calls to action, critical highlights, and warning states. It ensures high visibility against both light and dark backgrounds.
- **Neutral (Tactical White - #F8F9FA):** The foundation for the light mode interface, providing a clean, paper-like surface for data density.
- **Dark Mode:** When active, the surface shifts to **Deep Charcoal (#121212)**. In this mode, Pitch Green is used sparingly as a "glow" accent or border highlight to maintain the athletic energy without causing eye strain during night-time film reviews.

## Typography

This design system employs a dual-font strategy to balance energy with legibility.

- **Montserrat** is used for headlines and display metrics. Its geometric strength conveys confidence and a modern sports-broadcast feel.
- **Inter** is used for all body text, data tables, and UI labels. Its high x-height and neutral tone ensure maximum readability during fast-paced use. 

**Special Considerations:**
- **Turkish Localization:** Both fonts fully support Turkish characters (ç, ğ, ı, ö, ş, ü). Ensure line-heights remain generous to accommodate lowercase descenders and accents.
- **Tabular Numerals:** For data-heavy views, utilize Inter’s "tnum" (tabular figures) feature to ensure columns of numbers align vertically for easy comparison.

## Layout & Spacing

The layout utilizes a **12-column fluid grid** for desktop and a **4-column grid** for mobile. A strict 8px spacing rhythm ensures that elements feel organized and systematic.

- **Grid System:** On desktop, use a max-width container of 1440px. 
- **Card-Based Architecture:** Information is encapsulated in cards to allow for flexible reflow. On mobile, cards typically stack vertically; on desktop, they span 3, 4, or 6 columns depending on the data density.
- **Safe Zones:** High-performance dashboards should maintain a minimum "Tactical Margin" of 24px between disparate data groups to prevent cognitive overload.

## Elevation & Depth

To maintain "Tactical Clarity," depth is used to indicate priority and interactivity rather than just for decoration.

- **Surface Levels:**
  - **Level 0 (Background):** Tactical White or Deep Charcoal.
  - **Level 1 (Cards/Panels):** Pure white (light mode) or #1E1E1E (dark mode).
  - **Level 2 (Popovers/Modals):** Slight elevation with a subtle shadow.
- **Shadows:** Use "Ambient Shadows"—soft, low-opacity (#000000 at 8%) with a 12px blur and 4px vertical offset. This creates a "lifted card" effect that distinguishes interactive modules from the background.
- **Interaction:** On hover, interactive cards should increase their shadow spread slightly and shift -2px on the Y-axis to provide tactile feedback.

## Shapes

The shape language is defined by **rounded precision**. 

- **Standard Radius (8px):** Applied to buttons, input fields, and cards. This softens the "hard data" to make the platform feel more accessible and user-friendly.
- **Icon Containers:** Circular or highly rounded containers (pill-shaped) should be used for player avatars or tactical markers to distinguish them from structural UI components.
- **Visual Consistency:** Borders should be thin (1px) and use a low-contrast neutral grey to define boundaries without adding visual noise.

## Components

### Buttons
- **Primary:** Pitch Green background with Tactical White text. 8px radius. Bold Montserrat text.
- **Action:** Alert Orange for high-priority functions (e.g., "End Session," "Go Live").
- **Ghost:** Performance Blue outline for secondary actions like "Export" or "Filter."

### Tactical Chips
- Small, pill-shaped indicators (12px radius) used for player positions or tagging events (e.g., "Goal," "Substitution"). Use Performance Blue for active states.

### Status Indicators
- **Processing:** Pulsing Blue dot.
- **Success:** Solid Green check.
- **Warning:** Solid Orange exclamation.
- These must include text labels to ensure accessibility and clarity during high-stress coaching moments.

### Cards
- The core unit of the design system. Cards must have a 1px border (#E9ECEF) and an 8px corner radius. Headlines within cards should use Montserrat Medium 16px.

### Inputs
- Clean, 8px rounded boxes. In dark mode, use a slightly lighter charcoal background than the main surface to create a "well" effect.

### Icons
- Use a consistent 2px stroke weight. Icons should be themed around tactical boards (e.g., whistle for drills, clipboard for tactics, stopwatch for intervals).