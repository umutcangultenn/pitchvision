# PitchVision Lite - Project Structure & Architecture

## Overview
PitchVision Lite is a low-cost "Lite Analysis + Scouting" SaaS platform for amateur leagues and youth academies (U8-U17).

## Architecture
- **Backend:** FastAPI (Python) - High performance, asynchronous.
- **Computer Vision:** OpenCV + YOLO Abstraction.
- **Database:** PostgreSQL (SQLModel/SQLAlchemy) - Structured tactical data.
- **Storage:** MinIO/S3 - Video and clip storage.
- **Frontend:** Next.js (TypeScript) + Tailwind CSS - Responsive and interactive.
- **Workers:** Celery/Redis - Asynchronous video processing.

## File Structure
```text
pitchvision-lite/
├── backend/
│   ├── app/
│   │   ├── api/          # Route handlers
│   │   ├── core/         # Config, security
│   │   ├── db/           # Session, base models
│   │   ├── models/       # SQLModel definitions
│   │   ├── schemas/      # Pydantic schemas
│   │   ├── services/     # Business logic
│   │   ├── cv/           # Computer Vision pipeline
│   │   │   ├── calibration.py
│   │   │   ├── detector.py
│   │   │   └── tracker.py
│   │   ├── analytics/    # Tactical metrics engine
│   │   └── reports/      # PDF/HTML generation
├── frontend/
│   ├── app/              # Next.js pages
│   ├── components/       # UI Library
│   └── lib/              # API clients, utils
├── docker-compose.yml
└── README.md
```

## Data Models
1. **Organization:** Multi-tenant root.
2. **Team:** Squad management.
3. **Player:** Profile & Passport.
4. **Match:** Game sessions & video links.
5. **Detection/TrackPoint:** Raw CV data.
6. **TacticalAlert:** AI-generated insights.
7. **Clip:** Extracted video segments.
